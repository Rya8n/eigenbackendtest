to_be_processed = [[1, 2, 0],[4, 5, 6],[7, 8, 9]]

def get_first_diagonal_value(matrix):
    to_be_returned = 0
    for idx in range(len(matrix)):
        to_be_returned = to_be_returned + matrix[idx][idx]\
    
    return to_be_returned
    
def get_second_diagonal_value(matrix):
    to_be_returned = 0
    for idx in range(len(matrix)):
        to_be_returned = to_be_returned + matrix[len(matrix) - 1 - idx][idx]
    return to_be_returned

print(get_first_diagonal_value(to_be_processed) - get_second_diagonal_value(to_be_processed))