to_be_processed = "NEGIE1"

letters = to_be_processed.rstrip('0123456789')
numbers = to_be_processed[len(letters):]

to_be_returned = ""
for idx in range(len(letters)):
    to_be_returned = to_be_returned + letters[len(letters) - idx - 1]

to_be_returned = to_be_returned + numbers
print(to_be_returned)