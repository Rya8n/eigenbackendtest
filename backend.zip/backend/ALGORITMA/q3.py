INPUT = ["xc", "dz", "bbb", "dz"]
QUERY = ["bbb", "ac", "dz"]
output = []

for idx in range(len(QUERY)):
    repeat_count = 0
    for jdx in range(len(INPUT)):
        if QUERY[idx] == INPUT[jdx]:
            repeat_count = repeat_count + 1
    output.append(repeat_count)
    
print(output)