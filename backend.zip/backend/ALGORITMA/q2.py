import string 

long_sentence = "Saya sangat senang mengerjakan soal algoritma"

long_sentence = long_sentence.translate(str.maketrans('', '', string.punctuation))

words = long_sentence.split()

idx_longest = 0

for idx in range(len(words)):
    if len(words[idx]) <= len(words[idx_longest]):
        continue
    idx_longest = idx
    
    
print(str(words[idx_longest]) + ": " + str(len(words[idx_longest])) + " character")