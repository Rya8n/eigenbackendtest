# Eigen Tech-Test
Tech-test for Eigen

# Backend
1. Clone the repo
2. `docker-compose up -d` or `docker compose up -d`
2. `npm install`
3. `npm run dev`
4. Open `http://localhost:3000` in the browser


# Algorithm
1. Run the files using python 3 or higher
