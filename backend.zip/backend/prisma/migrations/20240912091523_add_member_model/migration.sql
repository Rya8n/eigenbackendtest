-- CreateTable
CREATE TABLE "members" (
    "code" CHAR(4) NOT NULL,
    "name" TEXT NOT NULL,

    CONSTRAINT "members_pkey" PRIMARY KEY ("code")
);
